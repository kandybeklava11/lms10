import javax.swing.plaf.SpinnerUI;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String[] Lessons1 = {"Tecnical lesson"};
        MyClass person =new MyClass("Kandybek","Isaev", 16,Lessons1 , "Lagman");
       person.Demokrat();
        System.out.println();
       MyClass person2=new MyClass();
       person2.Demokrat();
    }

}